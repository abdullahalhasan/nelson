<?php
 require_once 'db_qa.php';
dba_start("EMP1","01711370945","1001a","02");
?>